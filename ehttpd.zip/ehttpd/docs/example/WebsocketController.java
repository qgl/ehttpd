package com.ejiag.ehttpd.controller;


import com.ejiag.estar.catalina.handler.http.processor.IWebSocketProcessor;
import com.ejiag.estar.common.base.annotations.Controller;
import com.ejiag.estar.common.base.annotations.RequestMapping;
import com.ejiag.estar.common.base.annotations.RequestParam;
import com.ejiag.estar.common.exception.ServiceException;
import com.ejiag.etool.common.util.web.Res;

import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;

/**
 * websocket测试
 * @author qinggele
 *
 */
@Controller
public class WebsocketController{
	
	@RequestMapping(value = "/websocket")
    public Res websocket(
            @RequestParam(value = "format", defaultValue = "json", required = false) String format,
            @RequestParam(value = "callback", defaultValue = "", required = false) String callback,
            HttpRequest request, IWebSocketProcessor processor, WebSocketFrame frame) throws Exception {
        Res res = new Res();
        try {
        	res.commit();
        } catch (ServiceException e) {
            res.addError(e.getMessage());
        }
        return res;
    }
}